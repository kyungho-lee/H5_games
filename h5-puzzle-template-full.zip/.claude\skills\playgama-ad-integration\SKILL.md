---
name: playgama-ad-integration
description: Use when integrating Playgama Bridge SDK ads — interstitial, rewarded, banner. Use when ad buttons are not showing, QA Tool rewarded ad hangs or times out, qa_tool platform not treated as mock, or duplicate IIFE patch guard causes wrong platform to be locked in.
---

# Playgama Bridge SDK — Ad Integration

## Overview

Playgama Bridge SDK v1 광고 연동 완성 패턴.  
**SameGame Grid Protocol daily.html에서 QA 검증 통과가 확인된 코드를 기준**으로 작성된 레퍼런스 스킬.

이 스킬은 새 게임 페이지에 Playgama 광고를 연결할 때 사용한다.

---

## 아키텍처 원칙

```
게임 코드 → SG.CG.* (공통 인터페이스)
              ↑
         Playgama 환경: playgama.js가 SG.CG.* 를 Bridge로 패치
         CrazyGames 환경: crazygames.js가 SG.CG.* 구현
         기타/로컬: no-op (에러 없음)
```

- 게임 코드는 `SG.CG.*`만 호출. 플랫폼 분기 없음.
- `SG.PG.init()` 성공 시 `_patchCG()`가 `SG.CG.*` 메서드를 Bridge로 교체.

---

## ⚠️ 핵심 규칙 — 정적 Bridge 태그

Playgama QA Tool 환경에서는 **정적 `<script>` 태그**로 Bridge SDK를 넣어야 한다.
동적 로드만으로는 QA Tool이 `window.bridge`를 주입하지 못한다.

```html
<!-- ✅ 필수 — 모든 진입 가능한 HTML 파일에 동일하게 추가 -->
<script src="https://bridge.playgama.com/v1/stable/playgama-bridge.js"></script>
```

> **주의**: `playgama.js`도 동적 로드 경로를 유지하고 있어, 정적 태그와 중복되지 않도록
> `_loadSdkScript()`에서 이미 로드된 경우를 `document.querySelector`로 체크한다.

---

## HTML 구조

```html
<head>
  <!-- Playgama Bridge: 정적 태그 필수 (QA Tool window.bridge 주입 요건) -->
  <script src="https://bridge.playgama.com/v1/stable/playgama-bridge.js"></script>
  <!-- Ad SDK wrappers -->
  <script src="crazygames.js"></script>
  <script src="playgama.js"></script>
</head>
```

---

## 부트 시퀀스 (권장 패턴)

```javascript
(async () => {
  // sdkDisabled 비동기 에러 억제 (비-CG 도메인)
  window.addEventListener('unhandledrejection', function (evt) {
    var r = evt.reason;
    if (r && (r.code === 'sdkDisabled' ||
        (typeof r.message === 'string' && r.message.indexOf('sdkDisabled') !== -1))) {
      evt.preventDefault();
    }
  });

  if (window.bridge && typeof window.bridge.initialize === 'function') {
    await SG.PG.init();          // Bridge 선주입 → 즉시 사용
  } else {
    await SG.CG.init();          // CrazyGames SDK (우선)
    if (!SG.CG.isAvailable() && SG.PG) {
      await SG.PG.init();        // Playgama Bridge (폴백)
    }
  }
  SG.CG.loadingStart();
  init();                        // 게임 초기화
  SG.CG.loadingStop();           // game_ready 전송
})().catch(function (e) { console.error('[boot]', e); });
```

---

## 광고 연동 패턴

### 1. 인터스티셜 (미드게임)

```javascript
await SG.CG.requestMidgameAd();
// resolve 후 게임 진행
```

### 2. 리워드 광고

```javascript
async function requestReward(btn) {
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Loading…'; }

  if (SG.CG.isAvailable()) {
    const res = await SG.CG.requestRewardedAd('retry_reward');
    if (res && res.granted) {
      grantReward();   // 보상 지급
      return;
    }
    // granted:false = 사용자 취소 → 버튼 복원 (폴백 모달 없음)
    if (btn) { btn.disabled = false; btn.textContent = '📺 광고 시청'; }
    return;
  }

  // SDK 없음 → 폴백 모달
  showFallbackModal();
}
```

> **핵심**: `isAvailable() === true` + `granted: false` = 사용자 취소.
> 버튼만 복원하고 폴백 모달은 띄우지 않는다.
> `isAvailable() === false` 일 때만 폴백 모달로 진입.

### 3. 배너 광고

```javascript
SG.CG.showBanner();  // 유휴 화면 진입 시
SG.CG.hideBanner();  // 풀스크린 광고 직전
SG.CG.showBanner();  // 광고 완료/실패 후
```

---

## 플랫폼 이벤트

```javascript
// SG.PG.init() 이전에 등록해도 됨 (init 완료 후 자동 호출)
SG.PG._onAudioStateChanged = function (isEnabled) {
  soundManager.setMuted(!isEnabled); // false = 광고 중 뮤트
};
SG.PG._onPauseStateChanged = function (isPaused) {
  if (isPaused) pauseGame(); else resumeGame();
};
```

---

## zip 생성 (Playgama 배포)

Playgama 요건: 루트에 `index.html` + 나머지 flat 구조.

```powershell
$src = 'src'
$out = 'game.zip'
if (Test-Path $out) { Remove-Item $out }
$files = Get-ChildItem -Path $src -File | ForEach-Object { $_.FullName }
Compress-Archive -Path $files -DestinationPath $out -CompressionLevel Optimal
```

---

## 주요 트러블슈팅

### 리워드가 QA에서 주입 안 됨 (loading → failed만 보임)

**원인**: `failed` 후 이벤트 리스너가 제거되어 QA 주입 이벤트를 수신 못 함.
`playgama.js`의 `onState`에서 `failed` 시 즉시 `finish()` 호출하는지 확인.
현재 템플릿은 `failed` → 즉시 `finish()` 패턴으로 단순화되어 있음.

### `platform: mock` 유지

`window.SG &&` 같은 추가 조건이 부트 코드에 있으면 Playgama init이 skip됨.
index.html과 모든 HTML 파일의 부트 조건을 동일하게 유지할 것.

### `sdkDisabled` 콘솔 에러

비-CrazyGames 도메인에서 발생하는 정상 동작. 부트 IIFE 앞에 unhandledrejection 핸들러 추가.

### 광고 버튼이 표시 안 됨

버튼 노출 조건에 `SG.CG.isAvailable()` 체크 금지.
버튼은 항상 표시하고, SDK 체크는 `requestRewardedAd()` 내부에서 처리.

---

## QA 검증 체크리스트

| 단계 | 확인 항목 | 기대 동작 |
|------|----------|----------|
| 1 | `game_ready` 수신 | 30초 내 (loadingStop → sendMessage) |
| 2 | 인터스티셜 | `showInterstitial()` 호출 후 진행 |
| 3 | 리워드 granted | `rewarded→closed` 주입 → `{granted: true}` → 보상 지급 |
| 4 | 리워드 skipped | `closed`만 주입 → `{granted: false}` → 버튼 복원 |
| 5 | 배너 show/hide | 유휴/광고 전환 시 동작 |
